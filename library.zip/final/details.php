<?php
    $conn=mysqli_connect("localhost","root","","prac");
    if($conn == false)
    {
        die(mysqli_connect_error());
    }
    $username=$_POST['username'];
    $sql="Select * from register where username='$username'";
    $result=mysqli_query($conn,$sql);
    ?>
    <table>
        <tr>
        <td>Username</td>
        <td>Email:</td>
        <td>Mobile:</td>
</tr>
<?php
    if(mysqli_num_rows($result)>0)
    {
    ?>
        <?php
        while($row=mysqli_fetch_assoc($result))
        {
            ?>
            <tr>
                <td><?php echo $row['username'] ?></td>
                <td><?php echo $row['email']  ?></td>
                <td><?php echo $row['mobile']?></td>
        </tr>
        <?php
        }
        
    }
    ?>
    
?>