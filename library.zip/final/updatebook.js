function validateInputs() {
    var bookName = document.forms["form"]["bookname"].value;
    var category = document.forms["form"]["category"].value;
    var bookID = document.forms["form"]["bookid"].value;
    var copies = document.forms["form"]["copies"].value;
  
    if (bookName == "") {
      document.querySelector('input[name="bookname"]').nextElementSibling.innerHTML = "* Please enter a book name.";
      return false;
    }
  
    if (category == "") {
      document.querySelector('select[name="category"]').nextElementSibling.innerHTML = "* Please select a category.";
      return false;
    }
  
    if (bookID == "" ||isNaN(bookID)) {
      document.querySelector('input[name="bookid"]').nextElementSibling.innerHTML = "* Please enter a book ID.";
      return false;
    }
  
    if (copies == "" || isNaN(copies)) {
      document.querySelector('input[name="copies"]').nextElementSibling.innerHTML = "* Please enter a valid number of copies.";
      return false;
    }
  
    return true;
  }