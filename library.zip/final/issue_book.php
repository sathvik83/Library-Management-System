<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "books";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
$user_id=$_POST['email'];
$bookname=$_POST['bookname']; 
$category=$_POST['category']; 
$bookid=$_POST['bookid']; 
$bookauthor=$_POST['bookauthor']; 
$issuedate=$_POST['issuedate']; 
$return_date=$_POST['returndate']; 
$status="Borrowed";
///$tempname = $_FILES["uploadfile"]["tmp_name"];
//$db = mysqli_connect("localhost", "root", "", "db");
    //file uploaded
/*
    $sql = "INSERT INTO issue_book (book_id,book_name,book_author,issue_date,status,user_id) VALUES ('$bookid''$bookname','$bookauthor','$issuedate','$status','$user_id')";

    $result = mysqli_query($conn,$sql) or die(mysqli_error($sql));
    if($result){
       echo "Records were updated successfully.";
       
       

    } else {
        echo "ERROR: Could not able to execute $sql. ";
    }*/
    $stmt=$conn->prepare("insert into history VALUES(?,?,?,?,?,?,?)");
    $stmt->bind_param("sssssss",$bookid,$bookname,$bookauthor,$issuedate,$return_Date,$status,$user_id);
    $stmt->execute();
    echo "Data inserted";
    $stmt->close();
?>