<!DOCTYPE html>
<html>
<head>
	<title>Insert Page page</title>
</head>
<body>
	<center>
		<?php
		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$conn = mysqli_connect("localhost", "root", "", "login");
		// Check connection
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		// Taking all 5 values from the form data(input)
		$username = $_REQUEST['username'];
		$email = $_REQUEST['email'];
		$password = $_REQUEST['password'];
		$password2 = $_REQUEST['password2'];
		//$email = $_REQUEST['email'];
		// Performing insert query execution
		// here our table name is college
		$sql = "INSERT INTO registration VALUES ('$username',
			'$email','$password','$password2')";
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in a database successfully."
				. " Please browse your localhost php my admin"
				. " to view the updated data</h3>";

			echo nl2br("\n$username\n $email\n "
				. "$password\n $password2");
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		// Close connection
		mysqli_close($conn);
		?>
	</center>
</body>
</html>