<?php
/*error_reporting(0);

$msg = "";

// If upload button is clicked ...
if (isset($_POST['upload'])) 
{

	$name=$_POST['text'];
	$filename = $_FILES["uploadfile"]["name"];
	///$tempname = $_FILES["uploadfile"]["tmp_name"];
	//$folder = "./image/" . $filename;
	$conn = mysqli_connect("localhost", "root", "", "books");
	//$db = mysqli_connect("localhost", "root", "", "db");


	if(file_exists("upload/" .$_FILES["uploadfile"]["name"]))
	{
		$store=$_FILES["uploadfile"]["name"];
		$_SESSION['status']="image already exists. '$store.'";
	}else
	{
		// Get all the submitted data from the form
		$sql = "INSERT INTO book ('bookid','filename') VALUES ('$name','$filename')";
		$query_run=mysqli_query($conn,$sql);
		if($query_run)
		{
			move_uploaded_file($_FILES["uploadfile"]["tmp_name"],"upload/".$_FILES["uploadfile"]["name"]);
			$_SESSION['success']="Done";

		}
		else{
			$_SESSION['success']=" Not Done";
		}

	// Execute query
	/*mysqli_query($db, $sql);

	// Now let's move the uploaded image into the folder: image
	if (move_uploaded_file($tempname, $folder)) {
		echo "<h3> Image uploaded successfully!</h3>";
	} else {
		echo "<h3> Failed to upload image!</h3>";
	}
}
}
*/
?>

<!DOCTYPE html>
<html>
<head>
	<title>Add Book</title>
	<style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');
        * {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            font-size: 20px;
        }
        #main
        {
            display:flex;
            flex-wrap: wrap;
            background-color:gray;
            margin-left:10%;
			margin-right:10%;
            height:550px;
            width:80%;
        }
        #main1
        {
            display:flex;
            flex-wrap:wrap;
            width:100%;
            height:100px;
            justify-content: center;
            align-content: center;
        }
        #column1
        {
            display:flex;
            flex-direction: column;
            height:450px;
            width:40%;
			margin-left:10%;
        }
        #column2
        {
            display:flex;
            flex-direction: column;
            height:450px;
            width:40%;
			margin-right:10%;
        }
        label
        {
            font-size:30px;
			margin-bottom: 5px;
        }
        input[type=text],select
        {
            width:90%;
            height:35px;
            font-size:30px;
            border:none;
            border-radius: 4px;
        }
		input[type=file]
		{
			width:90%;
			height:35px;
			display:None;
			border:2px solid black;
			border-radius:4px;
		}
		#image
		{
			width:90%;
			height:35px;
			border:none;
			border-radius: 4px;
			background-color: white;
		}
        #reset
        {
            width:35%;
            height:70px;
            font-size:30px; 
			display: inline-block;
			float: left;
			margin-right:15%;
			border-radius:4px;
			border:none;
        }
		#submit
		{
			width:35%;
			height:70px;
			font-size:30px;
			display: inline-block;
			float:left;
			margin-left: 15%;
			border-radius: 4px;
			border:none;
		}
		#button
		{
			margin-top:20px;
			height:120px;
            width:90%;
			display:inline-block;
			float:left;
		}
		#error1,#error2,#error3,#error4,#error5,#error6
		{
			margin:0;
			padding:0;
			width:90%;
			height:20px;
		}
    </style>
</head>

<body>
	<!--<div id="content">
		<form method="POST" action="code.php" enctype="multipart/form-data">
			<div class="form-group">
			<input type="text" name="bookid" placeholder="enter your text">
				<input class="form-control" type="file" name="uploadfile" value="uploadfile" />
				
			</div>
			<div class="form-group">
				<button class="btn btn-primary" type="submit" name="upload">UPLOAD</button>
			</div>
		</form>
	</div>
	
	</div>
-->
<div id="main">
        <div id="main1">
            <h1>ADD BOOK</h1>
        </div>
			<div id="column1">
			<!--<form method="POST" action="code.php" enctype="multipart/form-data">-->
				<label for="bookname">BookName</label>
				<input type="text" id="bookname" name="bookname">
				<div id="error1"></div>
				<label for="category">Category</label>
				<select name="category" id="category">
				<option value="-1">Select</option>
					<option value="Academic TextBook">Academic TextBook</option>
					<option value="Literature">Literature</option>
					<option value="History">History</option>
					<option value="Science">Science</option>
					<option value=" Art and Humanities">Art and Humanities</option>
					<option value="Career Development">Career Development</option>
					<option value="Leisure">Leisure</option>
				</select>
				<div id="error2"></div>
				<label for="bookid">Book id</label>
				<input type="text" id="bookid" name="bookid">
				<div id="error3"></div>
			</div>
			<div id="column2">
				<label for="bookauthor">BookAuthor</label>
				<input type="text" id="bookauthor" name="bookauthor">
				<div id="error4"></div>
				<label for="copies">Copies</label>
				<input type="text" id="copies" name="copies">
				<div id="error5"></div>
				<label for="UploadImage">UploadImage</label>
				<div id="image">
					<label for="inputimage" id="browse">Browse
					<input type="file" id="inputimage" accept="image/png,image/jpg,image/jpeg">
					<span id="imageName"></span>
					</label>
				</div>
				<div id="error6"></div>
				<div id="button">
					<input type="reset" name="reset" id="reset" value="Reset">
					<input type="submit" name="upload" id="submit" value="Add Book" onclick="return validate()">
				</div>
			</div>
    	</div>
		<script>
			let input=document.getElementById("inputimage");
			let imageName=document.getElementById("imageName");
			input.addEventListener("change",()=>
			{
				let inputImage=document.querySelector("input[type=file]").files[0];
				imageName.innerText=inputImage.name;
			})
			function validate()
			{
				var bookname=document.getElementById('bookname').value.trim();
				var category=document.getElementById('category').value;
				var bookid=document.getElementById('bookid').value;
				var bookauthor=document.getElementById('bookauthor').value.trim();
				var copies=document.getElementById('copies').value;
				//var span=document.getElementById('imageName').value;
				var flag1=1,flag2=1,flag3=1,flag4=1,flag5=1;
				//var flag6=1;
				if(bookname=="")
				{
					document.getElementById('error1').innerText="Enter bookname";

				}
				else
				{
					document.getElementById('error1').innerText="";
					flag1=0;
				}
				if(category=="-1")
				{
					document.getElementById('error2').innerText="Select Category";
				}
				else
				{
					document.getElementById('error2').innerText="";
					flag2=0;
				}
				if(bookid=="")
				{
					document.getElementById('error3').innerText="Enter bookid";
				}
				else
				{
					document.getElementById('error3').innerText="";
					flag3=0;
				}
				if(bookauthor=="")
				{
					document.getElementById('error4').innerText="Enter bookauthor";
				}
				else
				{
					document.getElementById('error4').innerText="";
					flag4=0;
				}
				if(copies=="")
				{
					document.getElementById('error5').innerText="Enter copies";
				}
				else
				{
					document.getElementById('error5').innerText="";
					flag5=0;
				}
				/*if(span=="")
				{
					document.getElementById('error6').innerText="Select Image";
				}
				else
				{
					document.getElementById('error6').innerText="";
					flag6=0;
				}*/
				if(flag1==0&&flag2==0&&flag3==0&&flag4==0&&flag5==0)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			</script>
</body>

</html>
