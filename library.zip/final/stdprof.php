<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyProfile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="stdstyle.css">
    <link rel="stylesheet" type="text/css" href="stylech.css">
</head>
<body>
<div class="row">
  <div class="column left">
    <img src="content1.jpeg" class="two">
    <a href="#">MyProfile</a>
    <a href="#">Library loan</a>
    <a href="#">Books</a>
    <a href="#">Members</a>
    <a href="#">Logout</a>
  </div>
  <div class="column middle">
  <div id="nav2">
            <form action="/action_page.php">
            <input type="text" placeholder="Search.."name="search">
            <button type="submit"><i class="fa fa-search"></i></button>
          </form>
    </div>
    <div class="book">
            <img src="rk.jpg" alt="Book 1">
            <h3>Book 1</h3>
            <p>Author: Author 1</p>
            <p>Genre: Fiction</p>
            <p>Year: 2020</p>
            <button>Borrow</button>
          </div>
    <!--
    <div>
        <img src="rk.jpg" class="one">

        <img src="second.jpg" class="one">
        <img src="img1.jpg" class="one">
        <img src="a1.jpg" class="one">
  </div>
  <div class="column right">
-->

  </div>
</div>
    
</body>
</html>