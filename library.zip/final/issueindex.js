const setError = (element, message) => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');

    errorDisplay.innerText = message;
    inputControl.classList.add('error');
    inputControl.classList.remove('success')
}

const setSuccess = element => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');

    errorDisplay.innerText = '';
    inputControl.classList.add('success');
    inputControl.classList.remove('error');
}

function validate()
{
    const form = document.getElementById('form');
const bookname = document.getElementById('bookname');
const category = document.getElementById('category');
const bookid = document.getElementById('bookid');
const bookauthor = document.getElementById('bookauthor');
const studentemail=document.getElementById('studentemail');
const booknameValue = bookname.value.trim();
    const categoryValue = category.value.trim();
    const bookidValue = bookid.value.trim();
    const bookauthorValue = bookauthor.value.trim();
    const studentemailValue = studentemail.value.trim();
    var flag=0,flag1=0,flag2=0,flag3=0,flag4=0;

    if(booknameValue === '') {
        setError(bookname, 'bookname is required');
    } else {
        setSuccess(bookname);
        flag=1;
    }

    if(categoryValue =='-1') {
        setError(category, 'bookcategory is required');
    } else {
        setSuccess(category);
        flag1=1;
    }

    if(bookidValue === '') {
        setError(bookid, 'bookid is required');
    } else {
        setSuccess(bookid);
        flag2=1;
    }

    if(bookauthorValue === '') {
        setError(bookauthor, 'bookauthor is requried');
    } else {
        setSuccess(bookauthor);
        flag3=1;
    }
    if(studentemailValue === '') {
        setError(studentemail, 'no of copies is required');
    } else {
        setSuccess(studentemail);
        flag4=1;
    }
    if(flag==1&&flag1==1&&flag2==1&&flag3==1&&flag4==1)
    {
        return true;
    }
    else
    {
        return false;
    }
}