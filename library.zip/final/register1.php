<?php

include 'config.php';
if(isset($_POST['submit']))
{
   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $phno = mysqli_real_escape_string($conn,$_POST['phno']);
   $caste= mysqli_real_escape_string($conn,$_POST['caste']);
   $pass = mysqli_real_escape_string($conn, $_POST['password']);
   $cpass = mysqli_real_escape_string($conn, $_POST['cpassword']);
   $filename = $_FILES['uploadfile']['name'];
   $filename_temp=$_FILES['uploadfile']['tmp_name'];
  ///$tempname = $_FILES["uploadfile"]["tmp_name"];
  $folder = "images/";
  //$db = mysqli_connect("localhost", "root", "", "db");
  /* $image = $_FILES['image']['name'];
   $image_size = $_FILES['image']['size'];
   $image_tmp_name = $_FILES['image']['tmp_name'];
   $image_folder = 'uploaded_img/'.$image;*/

   $select = mysqli_query($conn, "SELECT * FROM `user_form` WHERE email = '$email' AND password = '$pass' ") or die('query failed');

   if(mysqli_num_rows($select) > 0){
      $message[] = 'user already exist'; 
   }else{
      if($pass != $cpass){
         $message[] = 'confirm password not matched!';
      } else{
         if($pass != $cpass){
            $message[] = 'confirm password not matched!';
         } /*elseif($image_size > 2000000){
            $message[] = 'image size is too large!';
         }*/else{
            $insert = mysqli_query($conn, "INSERT INTO `user_form`(name, email, password,phno,caste,image ) VALUES('$name', '$email', '$pass', '$phno','$caste','$filename')") or die('query failed');
   
          if($insert){
               //move_uploaded_file($image_tmp_name, $image_folder);
               $message[] = 'registered successfully!';
               header('location:login.php');
            }else{
               $message[] = 'registeration failed!';
            }
         }
      }
   
   }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Student Registration</title>
   <link rel="stylesheet" href="css/Student Registration.css">
   <script defer src="js/Student Registration.js"></script>
   <style>


      img{
         height:830px;
         width:1160px;
         position:relative;
         padding:10px 20px 10px 10px;
      }


      </style>
</head>
<body> 
<div> 
<div class="form-container">
   <form action="" method="post" onclick="return validate()" enctype="multipart/form-data">
      <h3>Register Now</h3>
      <input type="text" name="name" placeholder="Enter Username" class="box" id="username" >
      <div id="error"></div>
      <input type="email" name="email" placeholder="Enter Email" class="box" id="email">
      <div id="error1"></div>
      <input type="text" name="phno" placeholder="Enter Phonenumer" class="box" id="phno"> 
      <div id="error2"></div>
      <input type="text" name="address" placeholder="Enter Address" class="box" id="address"> 
      <div id="error3"></div>
      <input type="text" name="caste" placeholder="Enter Caste" class="box" id="caste">
      <div id="error4"></div>
      <input type="password" name="password" placeholder="Enter Password" class="box" id="password">
      <div id="error5"></div>
      <input type="password" name="cpassword" placeholder="Enter Confirm Password" class="box" id="cpassword">
      <div id="error6"></div>
      <input type="file" name="uploadfile" class="box" accept="image/jpg, image/jpeg, image/png">
      <input type="submit" name="submit" value="Register Now" class="btn"> 
   </form>
   <p>Already have an account? <a href="login.php">Login Now</a></p>
</div>
<div id="form-image">
   <img src="Student.jpg">
</div>
</div>
</body>
</html>