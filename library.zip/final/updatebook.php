<?php
// Connect to the database
/*
// Insert data into the database

   $bookid = $_POST['bookid'];
   // $product_type = $_POST['product_type'];
    //$cost_of_product = $_POST['cost_of_product'];
    //$name_of_seller = $_POST['name_of_seller'];

    $product_img = $_FILES['product_img']['name'];
   // $product_image_temp = $_FILES['product_img']['tmp_name'];
    $product_image_folder = "upload/";

    // Move uploaded file to destination folder
    if (move_uploaded_file($product_image_temp, $product_image_folder.$product_img)) {
        // File uploaded successfully
        $stmt = $conn->prepare("INSERT INTO book ('bookid','filename') VALUES (?,?)");
        $stmt->bind_param("ss", $bookid,$product_img);

        $stmt->execute();
        echo "Data inserted successfully";
        $stmt->close();
    } else {
        // Failed to upload file
        echo "Error uploading file.";
    }

$conn->close();
*/

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "books";

    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) 
    {
        die("Connection failed: " . mysqli_connect_error());
    }

    $bookname=$_POST['bookname']; 
    $category=$_POST['category']; 
    $bookid=$_POST['bookid']; 
    $copies=$_POST['copies']; 
    $sql = "UPDATE addbook SET copies=$copies WHERE bookid=$bookid";
    if(mysqli_query($conn, $sql)){
       echo "Records were updated successfully.";
       
       

    } else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }

?>