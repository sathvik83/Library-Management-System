<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="finalcsshome.css">

    <style>
    .row {
        display: flex;
        flex-wrap:wrap;
        width:100%;
        height:450px;
    }
.column {
    display:flex;
    flex-wrap:wrap;
    width:300px;
    height:450px;  
    margin:50px;
    box-shadow:0 0 10px 5px whitesmoke;
    color:white;
}
.card {
    display:flex;
    flex-wrap:wrap;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
    transition: 0.3s;
    width:300px;
    flex-direction:row;
    height:320px;
    background-repeat:no-repeat;
    background-size:cover;
}
.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}
.container {
    display:flex;
    flex-wrap:wrap;
    flex-direction:column;
    width:300px;
    height:130px;
}
.button{
    text-align:center;
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
</head>
<body>
<header>
        <nav>
            <a href="/" class="logo"><img src="" alt=""></a>
            <div class="end_bx">
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Movies</a></li>
                    <li><a href="#">Series</a></li>
                    <li>Category <i class="fas fa-angle-down"></i>
                        <div class="list">
                            <a href="#">Fantasy</a>
                            <a href="#">Popular</a>
                            <a href="#">Magzines</a>
                            <a href="#">Horror</a>
                            <a href="#">MAgic</a>
                            <a href="#">Crime</a>
                        </div>
                    </li>
                </ul>
                <div class="search">
                    <input type="text" placeholder="Search books..." id="search">
                    <i class="fas fa-search" id="search_icon"></i>
                    <div class="search_bx2">
                        <!-- <a href="#">
                            <img src="mimg/a perfact.jpg" alt="">
                            <div class="content2">
                                <h6>A Perfact</h6>
                                <p>2018</p>
                            </div>
                        </a> -->
                        <a href="images/crime2.jpg"></a>



                    </div>
                </div>
                <div class="bell">
                    <i class="fas fa-bell"></i>
                </div>
                <div class="user">
                    <img src="img/user.png" alt="Jahid Khan" title="jahid khan">
                </div>
            </div>
        </nav>

        <div class="content">
            <h6>No of pages: <span id="header_dur">450</span></h6>
            <h3 id="header_gen"><i class="fas fa-star"></i>6.5
                <span>Fantasy</span>
            </h3>
            <h1 id="header_title">The Art of Photography</h1>
            <p id="header_pra">If we take pictures that harm our subjects, no one will want to be photographed. If we manipulate our images and deceive our audience, no one will trust us. If we are not ethical in how we use photography, we risk jeopardizing the integrity of the industry as a whole..</p>
            <div class="btns">
               ?<!-- <a href="#video"> <button><i class="fas fa-play" id="play_btn"></i> </button></a>-->
                <button><i class="fas fa-plus"></i>Borrow</button>
            </div>
        </div>
        <div class="slider_btns">
            <h6 class="slider"></h6>
            <h6 class="slider"></h6>
            <h6 class="slider"></h6>
        </div>
    </header>
    <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "books";
        $bookname=$_POST['bookname']; 
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        $query="select * from addbook where bookname LIKE '%$bookname%'";
        $query_run=mysqli_query($conn,$query);
    if(mysqli_num_rows($query_run)>0)
    {
        ?>
    <div class="row">
        <?php
             while($row=mysqli_fetch_assoc($query_run))
            {
                ?>
                    <div class="column">
                        <?php
                        $img='images/'.$row['filename'].'';
                        ?>
                        <div class="card" style="background-image:url(<?=$img?>);">
                        </div>
                        <div class="container">
                            <b>Book Name:<?php echo $row['bookname']?></b></h4>
                            <b>Author:<?php echo $row['bookauthor']?></b>
                            <b>No Of Copies:<?php echo $row['copies']?></b> 
                            <b><center><button>Available</button></center></b> 
                        </div>
                    </div>
                <?php
            }
        ?>
    </div>
        <?php
    }
    else{
        echo "No record found";
    }?>
</body>
</html>