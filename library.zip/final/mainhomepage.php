<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div id="herosection">
        <div id="navigation">
            <div id="logo"></div>
            <div id="navbar">
                <div>
                    <ul>
                        <li><a href="#">About</a></li>
                       <!-- <li><a href="#">ContactUs</a></li>-->
                        <li><a href="#">Admin Login</a></li>
                        <li><a href="lgn.php">Login</a></li>
                       <!-- <li><a href="#" onclick="window.open('lgn.php', 'Login', 'width=100,height=100');">Login</a></li>-->
                    </ul>
                </div>
            </div>
        </div>
        <div id="content1">
            <div id="content11"></div>
            <div id="content12">
                <h1>Welcome To SRKREC Library</h1>
                <div id="content121"><a href="1.php">Student Registration</a></li></div>
                <!--<div id="content121"><a href="#" onclick="window.open('1.php', 'Registration', 'width=100,height=100');">Student Registration</a></div>-->
                <div id="content122"><a href="#">Teacher Registration</a></div>
            </div>
        </div>
    <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "books";
    
        $conn = mysqli_connect($servername, $username, $password, $dbname);
    ?>
        <div class="Dashboard">
            <div class="One">
                <h2>Horror Books</h2>
                    <?php
                    $category="Horror";
                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                        $query="select count(*) as count from addbook where category='$category'";
                        $result = mysqli_query($conn, $query);
                        $count = mysqli_fetch_assoc($result)['count'];
                        ?>
                        <h2><?php echo $count?><h2>
                            <?php
                    ?>
            </div>
            <div class="One">
                <h2>Fantasy books</h2>
                <?php
                    $category="fantasy";
                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                        $query="select count(*) as count from addbook where category='$category'";
                        $result = mysqli_query($conn, $query);
                        $count = mysqli_fetch_assoc($result)['count'];
                        ?>
                        <h2><?php echo $count?><h2>
                            <?php
                    ?>
            </div>
      <div class="One">
                <h2>Crime books</h2>
                <?php
                    $category="crime";
                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                        $query="select count(*) as count from addbook where category='$category'";
                        $result = mysqli_query($conn, $query);
                        $count = mysqli_fetch_assoc($result)['count'];
                        ?>
                        <h2><?php echo $count?><h2>
                            <?php
                    ?>
            </div>
      <div class="One">
                <h2>Art and photography books</h2>
                <?php
                    $category="Art And photography";
                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                        $query="select count(*) as count from addbook where category='$category'";
                        $result = mysqli_query($conn, $query);
                        $count = mysqli_fetch_assoc($result)['count'];
                        ?>
                        <h2><?php echo $count?><h2>
                            <?php
                    ?>
            </div>
      <div class="One">
                <h2>Total books</h2>
                <?php
                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                        $query="select count(*) as count from addbook";
                        $result = mysqli_query($conn, $query);
                        $count = mysqli_fetch_assoc($result)['count'];
                        ?>
                        <h2><?php echo $count?><h2>
                            <?php
                    ?>
            </div>  
      
    </div>
        <!--<div id="content21"></div>
        <div id="content22"></div>
        <div id="content23"></div>
        <div id="content24"></div>-->
        <div id="content3">
            <h1 id="first">"The library is the temple of learning, and learning has</h1>
            <h1 id="second">liberated more people than all the wars in history."</h1>
            <h1 id="third">-Carl T. Rowan</h1>
        </div>
    </div>
</body>
</html>