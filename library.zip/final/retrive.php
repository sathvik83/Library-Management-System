<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="homestyle.css">
    <style>
     @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');
     * {
            font-family: 'Poppins', sans-serif;
            box-sizing: border-box;
        }
        
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            font-size: 20px;
        }
        
        #navi {
            display: block;
            width: 100%;
            height: 80px;
            background-color:white;
        }
        
        #icon {
    width: 30%;
    height: 100px;
    background-image: url(SRKR.png);
    background-position:center;
    background-repeat: no-repeat;
    background-size:auto;
    float: left;
}

        
        ul {
            list-style-type: none;
        }
        
        li {
            float: right;
            width: 180px;
            height: 60px;
            color: black;
            margin-top: 20px;
            margin-bottom: 20px;
            font-size: 30px;
            padding: 0;
            text-align: center;
        }
        
        li a {
            text-decoration: none;
            color: black;
            text-align: center;
        }
        
        li a:hover,
        a:active {
            color: purple;
        }
    .row {
        display: flex;
        padding:30px;
        flex-wrap:wrap;
        width:100%;
        height:450px;
    }
.column {
    display:flex;
    flex-wrap:wrap;
    width:400px;
    height:550px;  
    margin:50px 50px 50px 65px;
    box-shadow:0 0 10px 5px whitesmoke;
    color:white;
}
.card {
    display:flex;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
    transition: 0.3s;
    width:400px;
    flex-direction:row;
    height:320px;
    background-repeat:no-repeat;
    background-size:cover;
}
.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}
.container {
    display:flex;
    flex-direction:column;
    width:400px;
    height:130px;
}
.container b
{
  margin:0;
  padding:0;
}

.slideshow {
  position: relative;
  height: 500px;
  width:100%;
  overflow: hidden;
}

.slideshow img {
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  opacity: 0;
  transition: opacity 2s ease-in-out;
}

.slideshow img:first-child {
  opacity: 1;
}

@keyframes slideshow {
  0% {
    opacity: 0;
  }
  20% {
    opacity: 1;
  }
  33.33% {
    opacity: 1;
  }
  53.33% {
    opacity: 0;
  }
  100% {
    opacity: 0;
  }
}

.slideshow img:nth-child(2) {
  animation: slideshow 5s infinite;
}

.slideshow img:nth-child(3) {
  animation: slideshow 5s infinite;
  animation-delay: 2.5s;
}
.search-container {
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: transparent;
}

.search-container form {
  display: flex;
  align-items: center;
  background-color: rgba(255, 255, 255, 0.2);
  border-radius: 25px;
  padding: 5px;
}

.search-container input[type="text"] {
  background-color: transparent;
  border: none;
  outline: none;
  font-size: 16px;
  color: #fff;
  padding: 10px;
  width: 500px;
}

.search-container button {
  background-color: transparent;
  border: none;
  outline: none;
  color: #fff;

  font-size: 16px;
  padding: 10px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.search-container button:hover {
  color: #000;
  background-color: #fff;
}
.button{
    text-align:center;
    background-color:green;
    border:none;
    width:150px;
    height:50px;
    color:white;
    font-size:20px;
}

</style>
</head>
<body>
<div id="navi">
        <div id="icon">
        </div>
        <div id="navbar">
            <ul>
                <li><a href="login.php?logout=">Logout</a></li>
                <li><a href="update_profile.php">MyProfile</a></li>
                <li><a href="History.php">History</a></li>
                <li><a href="retrive.php">Home</a></li>
            </ul>
        </div>
</div>
    <div class="slideshow">
            <img src="back.jpg">
            <img src="back2.jpg">
            <img src="back2.jpg">
    </div>
    <div class="search-container">
  <form action="searchbar.php" method="post">
    <input type="text"  name="bookname" placeholder="Search Books.......">
    <button type="submit"><i class="fa fa-search"></i></button>
  </form>
</div>

    <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "books";
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        $query="select * from addbook";
        $query_run=mysqli_query($conn,$query);
    if(mysqli_num_rows($query_run)>0)
    {
        ?>
    <div class="row">
        <?php
             while($row=mysqli_fetch_assoc($query_run))
            {
                ?>
                    <div class="column">
                        <?php
                        $img='images/'.$row['filename'].'';
                        ?>
                        <div class="card" style="background-image:url(<?=$img?>);">
                        </div>
                        <div class="container">
                            <b>Book Name:<?php echo $row['bookname']?></b></h4>
                            <b>Author:<?php echo $row['bookauthor']?></b>
                            <b>No Of Copies:<?php echo $row['copies']?></b> 
                            <b><center><button class="button">Available</button></center></b> 
                        </div>
                    </div>
                <?php
            }
        ?>
    </div>
        <?php
    }
    else{
        echo "No record found";
    }?>
</body>
</html>