function validate() {
    var username = document.getElementById('username').value.trim();
    var email = document.getElementById('email').value.trim();
    var phno = document.getElementById('phno').value.trim();
    var address = document.getElementById('address').value.trim();
    var caste = document.getElementById('caste').value.trim();
    var password = document.getElementById('password').value;
    var cpassword = document.getElementById('cpassword').value;
    var isValidEmail = email => {
        const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    var flag = 0,
        flag1 = 0,
        flag2 = 0,
        flag3 = 0,
        flag4 = 0,
        flag5 = 0,
        flag6 = 0;
    if (username == "") {
        document.getElementById('error').innerText = "Please enter a username";
        flag = 1;
    } else {
        document.getElementById('error').innerText = "";
    }
    if (email == "") {
        document.getElementById('error1').innerText = "Please enter a email-address";
        flag1 = 1;
    } else if (!isValidEmail(email)) {
        document.getElementById('error1').innerText = "Please enter a valid email-address";
        flag1 = 1;
    } else {
        document.getElementById('error1').innerText = "";
    }
    if (phno.length != 10) {
        document.getElementById('error2').innerText = "Enter only 10-digit number";
        flag2 = 1;
    } else {
        document.getElementById('error2').innerText = "";
    }
    if (address == "") {
        document.getElementById('error3').innerText = "Please enter a address";
        flag3 = 1;
    } else {
        document.getElementById('error3').innerText = "";
    }
    if (caste.length <= 3 && caste !== "") {
        document.getElementById('error4').innerText = "";
    } else {
        document.getElementById('error4').innerText = "Enter a valid caste";
        flag4 = 1;
    }
    if (password == "") {
        document.getElementById('error5').innerText = "Please enter a password";
        flag5 = 1;
    } else if (password.length < 8) {
        document.getElementById('error5').innerText = "Password must have length of 8";
        flag5 = 1;
    } else {
        document.getElementById('error5').innerText = "";
    }
    if (cpassword == "") {
        document.getElementById('error6').innerText = "Please enter a password";
        flag6 = 1;
    } else if (cpassword.length < 8) {
        document.getElementById('error6').innerText = "Password must be length of 8";
        flag6 = 1;
    } else if (cpassword !== password) {
        document.getElementById('error6').innerText = "Confirm password must be same as password";
        flag6 = 1;
    } else {
        document.getElementById('error6').innerText = "";
    }
    if (flag == 0 && flag1 == 0 && flag2 == 0 && flag4 == 0 && flag5 == 0 && flag6 == 0) {
        return true;
    } else {
        return false;
    }
}